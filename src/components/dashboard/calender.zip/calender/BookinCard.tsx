import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { User, Car, Clock, DollarSign } from "lucide-react"

interface Booking {
  id: string
  user: {
    firstName: string
    lastName: string
    email?: string
    phoneNumber?: string
  }
  service: string
  status: string
  timeslot: string
  totalAmount?: number
  model?: string
  category?: string
}

interface BookingCardProps {
  booking: Booking
}

export function BookingCard({ booking }: BookingCardProps) {
  const getStatusColor = (status: string) => {
    switch (status.toUpperCase()) {
      case "CONFIRMED":
        return "bg-green-100 text-green-800 border-green-200"
      case "PENDING":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "CANCELLED":
        return "bg-red-100 text-red-800 border-red-200"
      case "COMPLETED":
        return "bg-blue-100 text-blue-800 border-blue-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium">{booking.service}</CardTitle>
          <Badge className={`text-xs ${getStatusColor(booking.status)}`}>{booking.status}</Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center space-x-2 text-sm text-gray-600">
          <User className="h-4 w-4" />
          <span>
            {booking.user.firstName} {booking.user.lastName}
          </span>
        </div>

        {booking.model && (
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Car className="h-4 w-4" />
            <span>{booking.model}</span>
          </div>
        )}

        <div className="flex items-center space-x-2 text-sm text-gray-600">
          <Clock className="h-4 w-4" />
          <span>
            {new Date(booking.timeslot).toLocaleTimeString("en-US", {
              hour: "2-digit",
              minute: "2-digit",
            })}
          </span>
        </div>

        {booking.totalAmount && (
          <div className="flex items-center space-x-2 text-sm font-medium text-gray-900">
            <DollarSign className="h-4 w-4" />
            <span>${booking.totalAmount}</span>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
